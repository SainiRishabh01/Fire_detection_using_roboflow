-- Create tables
CREATE TABLE Authors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    nationality VARCHAR(100),
    birth_year INT
);

CREATE TABLE Books (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    author_id INT,
    price DECIMAL(10, 2),
    publication_year INT,
    quantity_available INT,
    FOREIGN KEY (author_id) REFERENCES Authors(id)
);

CREATE TABLE Customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    address VARCHAR(255)
);

CREATE TABLE Orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    book_id INT,
    quantity INT,
    order_date DATE,
    total_price DECIMAL(10, 2),
    FOREIGN KEY (customer_id) REFERENCES Customers(id),
    FOREIGN KEY (book_id) REFERENCES Books(id)
);

-- Retrieve top-selling books
SELECT b.title, SUM(o.quantity) as total_sold
FROM Books b
JOIN Orders o ON b.id = o.book_id
GROUP BY b.id, b.title
ORDER BY total_sold DESC
LIMIT 10;

-- Calculate total sales revenue for a given period
SELECT SUM(o.total_price) as total_revenue
FROM Orders o
WHERE o.order_date BETWEEN 'start_date' AND 'end_date';
